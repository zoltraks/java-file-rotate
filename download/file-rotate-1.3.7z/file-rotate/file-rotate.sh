java -jar file-rotate.jar "$@"
